<?php
/**
 * 通用数据迁移：任意版本（v1.1.0+）→ v1.8.0（由更新程序自动执行，$ctx 含 old/new/manifest）
 * 幂等设计：可重复执行，结果一致。
 * v1.8.0 新增（防火墙）：
 *   1) 运行错误日志 data/error.log → data/logs/error.log（受 .htaccess 保护，防 Web 直接读取泄露路径）
 *   2) 补写 data/.htaccess（缺失时）
 *   3) 防火墙配置项（fw_*）全部使用程序内置默认值，不写入配置文件——保持"后续版本调整默认值"的灵活性
 */
if (!defined('APP')) exit('Forbidden');

$msg = [];

/* 1) 补写 data/.htaccess（Apache 全目录拒绝访问；老站点若缺失则补齐） */
if (!is_file(DATA_DIR . '/.htaccess')) {
    @file_put_contents(DATA_DIR . '/.htaccess', "# 数据目录禁止一切 Web 访问（Apache）\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n");
    $msg[] = '已补写 data/.htaccess（数据目录 Web 访问保护）';
}

/* 2) 运行错误日志移入受保护目录（v1.8.0 变更） */
$oldLog = DATA_DIR . '/error.log';
$newLog = DATA_DIR . '/logs/error.log';
if (is_file($oldLog)) {
    if (!is_dir(DATA_DIR . '/logs')) {
        @mkdir(DATA_DIR . '/logs', 0775, true);
    }
    if (!is_file($newLog)) {
        if (@rename($oldLog, $newLog)) {
            $msg[] = '运行错误日志已移至 data/logs/error.log（受 .htaccess 保护）';
        } else {
            $msg[] = '提示：data/error.log 未能自动移动，请通过 FTP 手动移入 data/logs/（或删除）';
        }
    }
}

/* 3) v1.8.0 防火墙提示（无配置写入，仅更新历史记录用） */
$msg[] = '防火墙已就绪：默认开启（白名单→封禁名单→危险IP库→限流→自动策略），配置见后台「安全防护」';

return implode('；', $msg);
