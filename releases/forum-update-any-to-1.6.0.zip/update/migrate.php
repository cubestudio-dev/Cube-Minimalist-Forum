<?php
/**
 * 通用数据迁移：任意版本（v1.1.0+）→ v1.6.0（由更新程序自动执行，$ctx 含 old/new/manifest）
 * 幂等设计：只补齐缺失的配置键（各历史版本新增项的默认值），不覆盖用户已有配置；
 * 可重复上传执行，结果一致。旧版缺少的键补默认值后，后台各设置页即完整可用。
 */
if (!defined('APP')) exit('Forbidden');

$cfg = Store::read('config.php', []);
if (!is_array($cfg)) {
    $cfg = [];
}

/* 各历史版本新增配置键的默认值（仅在该键不存在时写入） */
$defaults = [
    'theme_color'      => '#0f766e', // v1.2.0 主题色
    'dark_default'     => 'system',  // v1.2.0 深色模式默认值
    'custom_css'       => '',        // v1.2.0 自定义 CSS
    'footer_text'      => '',        // v1.3.0 页脚文字自定义
    'footer_note'      => '',        // v1.3.0 页脚备注
    'live_interval'    => 20,        // v1.4.0 前台实时刷新间隔
    'monitor_interval' => 5,         // v1.4.0 监控页刷新间隔
    'log_days'         => 90,        // 日志保留天数
    'log_views'        => 0,         // 页面访问日志开关
    'monitor_on'       => 1,         // 存储告警开关
    'monitor_mb'       => 95,        // 存储告警阈值（MB）
    'quota_mb'         => 100,       // 存储配额（MB）
    'site_url'         => '',        // 站点地址
    'bind_domains'     => '',        // v1.6.0 绑定域名（留空不限制）
];
foreach ($defaults as $k => $v) {
    if (!array_key_exists($k, $cfg)) {
        $cfg[$k] = $v;
    }
}

/* 版本号推进到目标版本 */
$cfg['version'] = (string)$ctx['new'];
Store::write('config.php', $cfg);
