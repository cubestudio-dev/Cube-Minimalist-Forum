<?php
/**
 * 通用数据迁移：任意版本（v1.1.0+）→ v1.8.1（由更新程序自动执行，$ctx 含 old/new/manifest）
 * 幂等设计：可重复执行，结果一致。
 * v1.8.1（Cloudflare 适配）无需任何数据迁移：
 *   - 新配置项（fw_trust_cf / fw_cf_ranges）均走程序内置默认值，不写入配置文件——
 *     Cloudflare 适配默认开启，未使用 Cloudflare 的站点行为与旧版完全一致
 *   - 本迁移仅保留历史通用升级动作（幂等：已处理过的站点零改动）
 */
if (!defined('APP')) exit('Forbidden');

$msg = [];

/* 1) 补写 data/.htaccess（Apache 全目录拒绝访问；老站点若缺失则补齐） */
if (!is_file(DATA_DIR . '/.htaccess')) {
    @file_put_contents(DATA_DIR . '/.htaccess', "# 数据目录禁止一切 Web 访问（Apache）\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n");
    $msg[] = '已补写 data/.htaccess（数据目录 Web 访问保护）';
}

/* 2) 运行错误日志移入受保护目录（v1.8.0 变更，幂等保留以便更老版本一步到位） */
$oldLog = DATA_DIR . '/error.log';
$newLog = DATA_DIR . '/logs/error.log';
if (is_file($oldLog) && !is_file($newLog)) {
    if (!is_dir(DATA_DIR . '/logs')) {
        @mkdir(DATA_DIR . '/logs', 0775, true);
    }
    if (@rename($oldLog, $newLog)) {
        $msg[] = '运行错误日志已移至 data/logs/error.log（受 .htaccess 保护）';
    }
}

/* 3) v1.8.1 说明（无配置写入，仅更新历史记录用） */
$msg[] = 'Cloudflare 适配已就绪：默认自动识别 CF 网段并取真实访客 IP，无需任何配置；后台「安全防护」页可查看实时链路诊断';

return implode('；', $msg);
