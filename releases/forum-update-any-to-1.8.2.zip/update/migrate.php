<?php
/**
 * 通用数据迁移：任意版本（v1.1.0+）→ v1.8.2（由更新程序自动执行，$ctx 含 old/new/manifest）
 * 幂等设计：可重复执行，结果一致。
 * v1.8.2 一次性修复：v1.8.0/1.8.1 中「只保存总开关会把其余防护设置按默认值覆盖」的 bug
 * 会让配置出现「限流关 + 自动策略关 + 全部内置规则关 + 蜘蛛放行关」的典型指纹，
 * 本迁移检测到该指纹时删除这些被污染的键，使程序内置的推荐默认值（全部开启）重新生效。
 * 注意：不改动 fw_on（总开关是用户自己点的，尊重当前选择），不改动白名单（无法自动恢复）。
 */
if (!defined('APP')) exit('Forbidden');

$msg = [];

/* 1) 补写 data/.htaccess（Apache 全目录拒绝访问；老站点若缺失则补齐，幂等） */
if (!is_file(DATA_DIR . '/.htaccess')) {
    @file_put_contents(DATA_DIR . '/.htaccess', "# 数据目录禁止一切 Web 访问（Apache）\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n");
    $msg[] = '已补写 data/.htaccess（数据目录 Web 访问保护）';
}

/* 2) 运行错误日志移入受保护目录（v1.8.0 变更，幂等保留以便更老版本一步到位） */
$oldLog = DATA_DIR . '/error.log';
$newLog = DATA_DIR . '/logs/error.log';
if (is_file($oldLog) && !is_file($newLog)) {
    if (!is_dir(DATA_DIR . '/logs')) {
        @mkdir(DATA_DIR . '/logs', 0775, true);
    }
    if (@rename($oldLog, $newLog)) {
        $msg[] = '运行错误日志已移至 data/logs/error.log（受 .htaccess 保护）';
    }
}

/* 3) v1.8.2 一次性修复：检测被「总开关 bug」重置的防护配置并恢复推荐默认值 */
$c = Store::read('config.php', []);
if (is_array($c) && $c) {
    $poisoned = isset($c['fw_rl_on'], $c['fw_score_on'], $c['fw_r_empty_ua'], $c['fw_r_scan_path'], $c['fw_spider_allow'])
        && (int)$c['fw_rl_on'] === 0
        && (int)$c['fw_score_on'] === 0
        && (int)$c['fw_r_empty_ua'] === 0
        && (int)$c['fw_r_scan_path'] === 0
        && (int)$c['fw_spider_allow'] === 0;
    if ($poisoned) {
        $keys = ['fw_rl_on', 'fw_rl_pm', 'fw_rl_ban_min', 'fw_score_on', 'fw_score_threshold', 'fw_auto_ban_hours',
                 'fw_r_empty_ua', 'fw_r_script_ua', 'fw_r_scan_path', 'fw_r_inject', 'fw_spider_allow',
                 'fw_trust_cf', 'fw_trust_xff'];
        foreach ($keys as $k) {
            unset($c[$k]);
        }
        Store::write('config.php', $c);
        $msg[] = '检测到曾被 v1.8.0/1.8.1「总开关误重置」bug 关闭的防护配置，已恢复为推荐默认值（限流与自动策略重新开启、CF 适配重新开启；白名单无法自动恢复，如配置过请到安全防护页重新填写）';
        if (function_exists('log_action')) {
            log_action('update_migrate', '已自动修复被误重置的防护设置（恢复推荐默认值）');
        }
    }
}

/* 4) v1.8.2 说明 */
$msg[] = 'IP 归属地已修复：历史「未知」记录会自动按未处理重新查询，到安全防护页点「查询本页归属地」即可补齐真实数据';

return implode('；', $msg);
